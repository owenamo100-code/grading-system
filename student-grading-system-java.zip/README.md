# Student Grading System (Java + Spring Boot)

Responsive student grading website with a Java backend. Java validates records, stores the submitted values in Java arrays/lists for processing, assigns grades, calculates the average, and finds the highest score. The browser interface has working Add, Remove, Calculate, and Reset buttons.

## Requirements
- Java 17+
- Maven 3.6+
- Internet for Maven to download dependencies the first time

## Run locally
From this project folder:
```bash
mvn spring-boot:run
```
Then open http://localhost:8080

## Grade boundaries used
- 80–100: A
- 70–79.99: B
- 60–69.99: C
- 50–59.99: D
- below 50: F

## Important deployment note
GitHub Pages only serves static files and does not run Java/Spring Boot. To publish this as a working website, deploy the complete Spring Boot project to a Java-capable host. A GitHub repository can hold the source code, but a repository/Gist link alone does not run the Java backend.
