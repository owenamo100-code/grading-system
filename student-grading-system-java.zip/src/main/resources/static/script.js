const students = [];

const form = document.getElementById("studentForm");
const nameInput = document.getElementById("studentName");
const scoreInput = document.getElementById("studentScore");
const studentRows = document.getElementById("studentRows");
const message = document.getElementById("message");
const calculateButton = document.getElementById("calculateButton");
const resetButton = document.getElementById("resetButton");
const resultsPanel = document.getElementById("resultsPanel");

function showMessage(text, success = false) {
  message.textContent = text;
  message.className = success ? "message success" : "message";
}

function renderStudents() {
  studentRows.replaceChildren();

  if (students.length === 0) {
    const row = document.createElement("tr");
    row.className = "empty-row";
    const cell = document.createElement("td");
    cell.colSpan = 4;
    cell.textContent = "No students added yet.";
    row.appendChild(cell);
    studentRows.appendChild(row);
    return;
  }

  students.forEach((student, index) => {
    const row = document.createElement("tr");
    [String(index + 1), student.name, String(student.score)].forEach(value => {
      const cell = document.createElement("td");
      cell.textContent = value;
      row.appendChild(cell);
    });

    const actionCell = document.createElement("td");
    const removeButton = document.createElement("button");
    removeButton.type = "button";
    removeButton.className = "remove-button";
    removeButton.textContent = "Remove";
    removeButton.addEventListener("click", () => {
      students.splice(index, 1);
      resultsPanel.hidden = true;
      renderStudents();
      showMessage("Student removed.", true);
    });
    actionCell.appendChild(removeButton);
    row.appendChild(actionCell);
    studentRows.appendChild(row);
  });
}

form.addEventListener("submit", event => {
  event.preventDefault();
  const name = nameInput.value.trim();
  const score = Number(scoreInput.value);

  if (!name) {
    showMessage("Enter the student's name.");
    nameInput.focus();
    return;
  }
  if (scoreInput.value === "" || !Number.isFinite(score) || score < 0 || score > 100) {
    showMessage("Enter a score between 0 and 100.");
    scoreInput.focus();
    return;
  }

  students.push({ name, score });
  renderStudents();
  resultsPanel.hidden = true;
  form.reset();
  nameInput.focus();
  showMessage(`${name} added successfully.`, true);
});

calculateButton.addEventListener("click", async () => {
  if (students.length === 0) {
    showMessage("Add at least one student before calculating results.");
    return;
  }

  calculateButton.disabled = true;
  calculateButton.textContent = "Calculating…";
  showMessage("");

  try {
    const response = await fetch("/api/grade", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(students)
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(errorText || "The Java service could not calculate results.");
    }

    const data = await response.json();
    const summary = document.getElementById("summary");
    summary.replaceChildren();

    const metrics = [
      ["Class average", data.average.toFixed(2)],
      ["Highest score", `${data.highestScore} — ${data.highestStudent}`],
      ["Students", String(data.students.length)]
    ];

    metrics.forEach(([label, value]) => {
      const box = document.createElement("div");
      box.className = "metric";
      const labelEl = document.createElement("span");
      labelEl.textContent = label;
      const valueEl = document.createElement("strong");
      valueEl.textContent = value;
      box.append(labelEl, valueEl);
      summary.appendChild(box);
    });

    const resultRows = document.getElementById("resultRows");
    resultRows.replaceChildren();
    data.students.forEach(student => {
      const row = document.createElement("tr");
      [student.name, String(student.score), student.grade].forEach((value, index) => {
        const cell = document.createElement("td");
        cell.textContent = value;
        if (index === 2) cell.className = "grade";
        row.appendChild(cell);
      });
      resultRows.appendChild(row);
    });

    resultsPanel.hidden = false;
    showMessage("Results calculated successfully by the Java application.", true);
    resultsPanel.scrollIntoView({ behavior: "smooth", block: "start" });
  } catch (error) {
    showMessage("Could not connect to the Java backend. Run the Spring Boot application and try again.");
  } finally {
    calculateButton.disabled = false;
    calculateButton.textContent = "Calculate results";
  }
});

resetButton.addEventListener("click", () => {
  students.length = 0;
  form.reset();
  resultsPanel.hidden = true;
  renderStudents();
  showMessage("All student records cleared.", true);
  nameInput.focus();
});

renderStudents();
