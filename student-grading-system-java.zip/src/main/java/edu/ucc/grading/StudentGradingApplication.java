package edu.ucc.grading;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentGradingApplication {
    public static void main(String[] args) {
        SpringApplication.run(StudentGradingApplication.class, args);
    }
}
