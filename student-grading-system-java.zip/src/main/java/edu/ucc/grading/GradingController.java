package edu.ucc.grading;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api")
public class GradingController {

    public record StudentInput(String name, double score) {}
    public record StudentResult(String name, double score, String grade) {}
    public record GradingResponse(List<StudentResult> students, double average,
                                  String highestStudent, double highestScore) {}

    @PostMapping("/grade")
    public GradingResponse gradeStudents(@RequestBody List<StudentInput> inputs) {
        if (inputs == null || inputs.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "Add at least one student before calculating results.");
        }

        List<StudentResult> results = new ArrayList<>();
        double total = 0;
        StudentInput highest = null;

        for (StudentInput input : inputs) {
            if (input == null || input.name() == null || input.name().trim().isEmpty()) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                        "Every student must have a name.");
            }
            if (input.score() < 0 || input.score() > 100) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                        "Scores must be between 0 and 100.");
            }

            StudentInput clean = new StudentInput(input.name().trim(), input.score());
            results.add(new StudentResult(clean.name(), clean.score(), gradeFor(clean.score())));
            total += clean.score();

            if (highest == null || clean.score() > highest.score()) {
                highest = clean;
            }
        }

        return new GradingResponse(results, total / results.size(),
                highest.name(), highest.score());
    }

    private String gradeFor(double score) {
        if (score >= 80) return "A";
        if (score >= 70) return "B";
        if (score >= 60) return "C";
        if (score >= 50) return "D";
        return "F";
    }
}
